# timesheet-be

Run docker command below to build and start backend
~~~
docker-compose up -d --build
~~~

Run docker command below to build and start only DB
~~~
docker-compose up -d --build db
~~~
