package com.cmc.timesheet.cache.service;

public interface MdRulesCacheService {

    /**
     * init rules to hash table
     */
    void initMdRulesCache();
}
