package com.cmc.timesheet.model.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardRequest {
    private String firstDay;
    private String currenDay;
}
