package com.cmc.timesheet.constants;

public class MasterDataConstant {
     /* Type */
    public static final String WORKING_TYPE = "working_type";

    public static final String LATE_COMING = "LATE_COMING";
    public static final String EARLY_LEAVING = "EARLY_LEAVING";
    public static final String LATE_COMING_EARLY_LEAVING = "LATE_COMING_EARLY_LEAVING";
}
