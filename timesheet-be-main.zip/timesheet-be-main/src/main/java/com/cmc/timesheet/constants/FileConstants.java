package com.cmc.timesheet.constants;

public class FileConstants {

    public static final String API_MAPPING = "/api/file";
}
