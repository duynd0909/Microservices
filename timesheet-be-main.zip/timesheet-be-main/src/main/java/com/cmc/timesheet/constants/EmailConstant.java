package com.cmc.timesheet.constants;

public class EmailConstant {
    public static final String VI = "vi";
    public static final String MONTH = "month";
    public static final String SUBJECT = " check công và giải trình công tháng ";
    public static final String TIMESHEET_LIST = "timeSheetList";
    public static final Integer NO_DATA = 0;
    public static final Integer DONE = 1;
    public static final Integer FAIL = 2;
}
