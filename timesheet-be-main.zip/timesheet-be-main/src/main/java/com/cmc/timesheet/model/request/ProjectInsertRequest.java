package com.cmc.timesheet.model.request;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProjectInsertRequest {
    private String name;

}