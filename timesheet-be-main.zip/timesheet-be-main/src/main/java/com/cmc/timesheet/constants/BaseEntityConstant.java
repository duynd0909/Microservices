package com.cmc.timesheet.constants;

public class BaseEntityConstant {

//    public static final String COLUMN_ID ="id";

    public static final String COLUMN_CREATED_BY ="created_by";

    public static final String COLUMN_CREATED_AT ="created_at";

    public static final String COLUMN_MODIFIED_BY ="modified_by";

    public static final String COLUMN_MODIFIED_AT ="modified_at";

    public static final String COLUMN_DELETED ="deleted";

    public static final String COLUMN_DELETED_AT ="deleted_at";

}