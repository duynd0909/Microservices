package com.cmc.timesheet.model.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteTimeLineResponse extends NoteTimeLineEntityResponse {

    private String strWorkingDate;

}
