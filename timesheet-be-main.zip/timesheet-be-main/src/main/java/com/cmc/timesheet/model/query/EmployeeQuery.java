package com.cmc.timesheet.model.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeQuery {

    private String name;

    private Integer projectId;

}